
class treeNode:
    def __init__(self):
        self.data=None
        self.node_id=0
        self.children=[]
        self.Coord=[]
        self.SensingRadius=0
        self.parent=None
        self.intersectedWith=[]
        self.subnodes=[]

    def addChild(self, node):
        self.children.append(node)

    def addSubnode(self, node):
        self.subnodes.append(node)

    def getSubnodes(self):
        return self.subnodes

    def getChildren(self):
        return self.children

    def setNodeId(self, node_id):
        self.node_id=node_id

    def getNodeId(self):
        return self.node_id

    def setCoord(self, coord):
        self.Coord=coord

    def getCoord(self):
        return self.Coord

    def setRadius(self, radius):
        self.SensingRadius=radius

    def getRadius(self):
        return self.SensingRadius

    def getSensorReading(self):
        return self.data

    def setSensorReading(self, sensorReading):
        self.data=sensorReading

    def deleteChild(self, nodeId):
        for node in self.children:
            if nodeId==node:
                self.children.remove(node)

