import math
from DataUpload import uploadData
from sympy.geometry import Circle, Point

class RedundancyDetector:

    def __init__(self, fno):
        self.dataSourceFile="wsns/"+str(fno)+".txt"#Simulation_output1.txt"#" #"" #
        #self.sensingRange=50 # sensing range is considered 50m
        self.lls=uploadData(file_name=self.dataSourceFile)

    '''
        calculate the distance two nodes.
        @param: circle1, it is a list represents the geographical coordinates (x, y) and radius (r) of the node. 
        It represents the first node
        @param: circle2, it is a list represents the geographical coordinates (x, y) and radius (r) of the node. 
        It represents the second node
    '''
    def findDistance(self, point1, point2):
        x1=point1[0]
        x2=point2[0]
        y1=point1[1]
        y2=point2[1]
        dist=math.sqrt(math.pow((x2-x1),2)+math.pow((y2-y1),2))
        return dist

    '''
       calculate the  area of intersection between the sensing range of two nodes.
       @param: circle1, it is a list represents the geographical coordinates (x, y) and radius of the node. 
       It represents the first node
       @param: circle2, it is a list represents the geographical coordinates (x, y) and radius of the node. 
       It represents the second node
    '''

    def circle_intersection_area(self, circle1, circle2):

        x1,y1,r1 = circle1
        x2,y2,r2 = circle2
        c1=Circle(Point(x1,y1),r1)
        c2=Circle(Point(x2,y2),r2)
        dist=RedundancyDetector.findDistance(self,[x1,y1],[x2,y2])
        intersection = c1.intersection(c2)
        if len(intersection) == 1:
            intersection.append(intersection[0])
        p1 = intersection[0]
        p2 = intersection[1]
        if (dist < r1 + r2):
            a = math.pow(r1,2)
            b = math.pow(r2,2)
            x = (a - b + math.pow(dist,2)) / (2 * dist)
            z = x * x
            y = math.sqrt(a - z)
            if (dist < abs(r2 - r1)):
                return math.PI * min(a, b)
            return a * math.asin(y / r1) + b * math.asin(y / r2) - y * (x + math.sqrt(z + b - a))

        return 0

    '''
        calculate the distance between two nodes to find out whether node2 located within the sensing range of node1
        @param: node1, it is the node to find its neighbor nodes
        @param: node2, it is the node to be check whether it is the neighbor of node1
    '''

    def IsNeighbor(self, node1, node2):

        distance=RedundancyDetector.findDistance(self, node1.getCoord(), node2.getCoord())
        if distance<=node1.getRadius():
            return True
        else:
            return False

    '''
        calculate the distance between two nodes to find out whether node2 intersects with node1 and not located within 
        the sensing range of node1
        @param: node1, it is the node to find its nodes with which there is overlapping in sensing range
        @param: node2, it is the node to be check whether it intersects with of node1 in sesning range
    '''

    def IsIntersectWith(self, node1, node2):

        distance=RedundancyDetector.findDistance(self, node1.getCoord(), node2.getCoord())
        if distance<(node1.getRadius()+node2.getRadius()) and (distance > node1.getRadius()):
            return True
        return False

    '''
        calculate the distance between two nodes to find out whether node2 intersects with node1 and not located within 
        the sensing range of node1
        @param: node, it is the node to find its 2 hop nodes with which there is overlapping in sensing range
    '''

    def find2Hops(self, node):

        tempNeighbors=node.getNeighbors()
        secondHopsList=[]
        for node_id in tempNeighbors:
            tempNode=self.lls.findNode(node_id)
            for nNode_id in tempNode.getNieghbos():
                nNode=self.lls.findNode(nNode_id)
                if RedundancyDetector.Is2HopeIntersection(self, node, nNode):
                    secondHopsList=secondHopsList+[nNode.getNodeId()]
            self.lls.updateNode(node)
            secondHopsList=[]




    def run(self):
        nbrs=[]
        temp=self.lls.head
        while temp is not None:
            ntemp=self.lls.head
            while ntemp is not None:
                if temp is not ntemp and RedundancyDetector.IsNeighbor(self,temp,ntemp):
                    cr1=temp.getCoord()+[temp.getRadius()]
                    cr2=ntemp.getCoord()+[temp.getRadius()]
                    nbrs.append(RedundancyDetector.circle_intersection_area(self,cr1,cr2))
                ntemp = ntemp.next
            print("node id:",temp.node_id,"  sensing areas:",nbrs)   #7853.974999999999 sensing circle area

            temp=temp.next
            nbrs=[]

    def isRedundancyExist(self):
        temp=self.lls.head
        while temp is not None:
            if len(temp.getNeighbors())>0:
                return True
            temp=temp.next
        return False


#obj=RedundancyDetector()
#obj.lls.printLinkedList()
#print(obj.lls.findNode(161).getCoord())








