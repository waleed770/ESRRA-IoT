import copy as cp
import math
from SetSimilaritySearch import all_pairs
import time

class sensor:

    def __init__(self, SNo, fname, readings):
        self.data=[]
        self.sensorNo=SNo
        self.fname=fname
        self.readings=readings
        self.data=sensor.uploadData(self, SNo)



    def uploadData(self, sensor_id):
        readingList = []
        count = 0
        global smallestsize

        try:
            f = open("datasets/Sensor_" + str(sensor_id) + ".txt", 'r')
            while True:
                readline = f.readline()
                if readline == '':
                    break
                count += 1
                if count > self.readings:
                    break

                if " " not in readline:
                    readingList.append(float(readline))
        except IOError as e:
            print(" file cann't be found or open")
        # readingList=refineData(readingList)

        return readingList


    def getData(self):
        sensor.uploadData(self)
        return self.data


class READA:

    def __init__(self, correlation_coeff, redundancy_factor, wsn_size, readings):
        self.groups={}
        self.readingsSize=readings
        self.correlation_coeff=correlation_coeff
        self.redundancy_factor=redundancy_factor
        self.wsn_size=wsn_size
        self.wsn=[]
        #create wsn sensors
        b_simi=[]
        b_pairs=[]
        b_avg=0
        for i in range(0,self.wsn_size):
            sobj=sensor(i+1,"data.txt", readings )
            if len(sobj.data)>0:
                #sobj.data=READA.refineData(self,sobj.data)
                self.wsn.append(cp.deepcopy(sobj))
                #b_simi.append(sobj.data)
        #b_pairs = list(all_pairs(b_simi, similarity_func_name="jaccard", similarity_threshold=0.1))
        #for e in b_pairs:
            #b_avg+=e[2]
        #print(len(b_simi),"   ",len(b_pairs), "  ", b_avg)

        #print("Similarity Before Aggregation:", (b_avg/len(b_pairs))*100)


    def findsmallest(self, wsn):

        temp=len(wsn[0].data)
        for i in range (1, len(wsn)):
            if temp>len(wsn[i].data):
                temp=len(wsn[i].data)
        return temp


    def refineData(self, data):
        temp=[]
        llen=len(temp)
        for e in data:
            if e not in temp:
                temp.append(e)
        return temp


    def dataGrouping(self):
        mea=[]
        avg=0.0
        simi=[]
        accu = 0
        sp_red=[]
        t_red=[]
        act=0
        est=0
        length=0
        spsum=0
        count=0
        tcount=0
        for i in range (1,100):
            self.groups[i]=[i*self.redundancy_factor,0,0]
        for e in self.wsn:
            avg+=sum(e.data)/len(e.data)

        for j in range(0,self.readingsSize):
            for k in range(0, len(self.wsn)):
                #avg += self.wsn[k].data[j]
                for l in range(1, len(self.groups)):


                    if int(self.wsn[k].data[j]) <= (self.groups[l][0]) \
                            or abs(self.wsn[k].data[j]-self.groups[l][0]) <= self.redundancy_factor:
                        if self.groups[l][1] == 0:
                            self.groups[l][1] = self.wsn[k].data[j]
                        else:
                            self.groups[l][1] = (self.groups[l][1]+self.wsn[k].data[j])/2
                        self.groups[l][2] = self.groups[l][2]+1
                        break

            for n in range (1, len(self.groups)):
                if abs(self.groups[n][1])>0:
                    count+=len(self.groups[n])
            tcount+=abs(len(self.wsn) - count)/len(self.wsn)
            print("count", count)
            print((len(self.wsn) - count)/len(self.wsn))
            count=0
        print(tcount/self.readingsSize*100)



        """
            for n in range (1, len(self.groups)):
                if abs(self.groups[n][1])>0:

                    mea.append(self.groups[n][1])
                    simi.append([self.groups[n][1]])
                    sp_red.append(self.groups[n][1])
            t_red.append(sp_red)
            #print("group:",self.groups )
            sp_red=[]
            a_pairs = list(all_pairs(simi, similarity_func_name="jaccard", similarity_threshold=0.0))
            # print("Simi After", simi)
            # b_simi = []
            sum_simi = 0

            for i in range(0, len(a_pairs)):
                spsum += a_pairs[i][2]
            length+=len(simi)

            simi = []
            for i in range(1, 100):
                self.groups[i] = [i * self.redundancy_factor, 0, 0]


            est+=sum(mea)/len(mea)

            #print("simi:", simi)

            #
            #print("accuracy:", accu/30)
            mea=[]
            #avg=0.0
            #simi=[]
        a_pairs = list(all_pairs(t_red, similarity_func_name="jaccard", similarity_threshold=0.0))
        sum_simi=0
        for e in a_pairs:
            sum_simi+=e[2]
        est=est/self.readingsSize
        #act=act/len(self.wsn)
        act += avg / len(self.wsn)
        accu = (abs(est - act) / act)
        print("Spatial Redundancy:", (spsum / length) * 100)
        print("Temporal Redundancy:",(sum_simi/len(a_pairs)) *100)


        print("Combined Accuracy:", accu*100)"""
reada=READA(1,5,200,500)
reada.dataGrouping()
