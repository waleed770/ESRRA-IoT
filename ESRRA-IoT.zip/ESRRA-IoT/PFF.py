from SetSimilaritySearch import all_pairs
import math
class sensor:

    def __init__(self, setsSize, SNo,redundantthreshold, dataSize, similarityThreshold, fname):
        self.data=[]
        self.sensorNo=SNo
        self.fname=fname
        self.setsSize=setsSize
        self. aggregatedReadings={}
        self.similarityThreshold = similarityThreshold
        self.redundantthreshold = redundantthreshold
        self.dataSize=dataSize
        self.data=sensor.uploadData(self, SNo)
        sensor.localAggregation(self)

    def uploadData(self, sensor_id):
        readingList = []
        count = 0
        global smallestsize

        try:
            f = open("datasets/Sensor_" + str(sensor_id) + ".txt", 'r')
            while True:
                readline = f.readline()
                if readline == '':
                    break
                count += 1
                if count > self.dataSize:
                    break

                if " " not in readline:
                    readingList.append(float(readline))
        except IOError as e:
            print(" file cann't be found or open")
        # readingList=refineData(readingList)

        return readingList

    def getData(self):
        sensor.uploadData(self)
        return self.data

    def localAggregation(self ):

        redundant=False
        if len(self.data)==0:
            return
        for i in range(0, int(self.dataSize/self.setsSize)):
            temp = []

            for j in range (i*self.setsSize, (i+1)*self.setsSize):
                if len(temp)==0:
                    temp.append((self.data[j],1))
                else:
                    for k in range(0, len(temp)):
                        value=temp[k][0]
                        if abs(self.data[j]-value)<= self.redundantthreshold:
                            temp[k]=(temp[k][0],temp[k][1]+1)
                            redundant = True
                            break
                    if not redundant:
                        temp.append((self.data[j],1))
                redundant = False
            self.aggregatedReadings[i]=temp



class CHaggregator:

    def __init__(self, wsnSize,  setsSize, redundantthreshold, dataSize, similarityThreshold, fname):
        self.wsn=[]
        self.wsnSize=wsnSize
        self.b_totalavge=0
        self.a_totalavge=0

        acc=[]

        for i in range(0, self.wsnSize):
            s=sensor(setsSize, i+1,redundantthreshold, dataSize, similarityThreshold, fname)
            if len(s.data)>0:
                #s.data=CHaggregator.refineData(self, s.data)
                self.b_totalavge+=CHaggregator.findAvg(self, s.data)
                self.wsn.append(s)
                #acc.append(s.data)
        self.b_totalavge=self.b_totalavge/len(self.wsn)

    def findAvg(self, data):
        return sum(data)/len(data)

    def findSimilarity(self,datasize, setsize, dictsets):
        sets=[]
        simililartyPairs=[]

        #sum=0.0
        count=0
        sp_sum=0
        t_red=[]
        t_sum=0.0
        tcount=0
        tlist=[]
        #form sets from dictionary
        for i in range(0, int(datasize / setsize)):
            for j in range(0, len(self.wsn)):
                s = self.wsn[j].aggregatedReadings[i]
                sets.append(CHaggregator.formSet(self, s))
                tlist.append(i for i in s)
                print (s)


            pairs = all_pairs(sets, similarity_func_name="jaccard", similarity_threshold=self.wsn[0].similarityThreshold)
            simililartyPairs=list(pairs)
            #print(sets)

            pruneList = []
            for k in range(0, len(simililartyPairs)):

                if sets[simililartyPairs[k][1]] not in pruneList:
                    pruneList.append(sets[simililartyPairs[k][1]])

            for l in pruneList:
                sets.remove(l)
            #print(sets)
            for s in sets:
                count+=len(s)
            tcount+=abs(len(self.wsn)* self.wsn[0].setsSize -count)/(len(self.wsn)*self.wsn[0].setsSize)
            print(count/len(self.wsn))
            count=0
            sets=[]
        print(tcount/(500/self.wsn[0].setsSize) *100)
        print(tlist[0])
        """
            pairs = list(all_pairs(sets, similarity_func_name="jaccard", similarity_threshold=0.0))

            for k in range(0,len(pairs)):
                sp_sum += pairs[k][2]
                count += 1

            if count>0:
                sp_sum=sp_sum/count
            temp=[]

            #calculate the temporal redundancy

            for e in sets:
                for el in e:
                    temp.append(el)
            t_red.append(temp)
            self.a_totalavge += sum(temp)/len(temp)
            temp=[]
            sets=[]
            count=0
        pairs = list(all_pairs(t_red, similarity_func_name="jaccard", similarity_threshold=0.0))

        for k in range(0, len(pairs)):
            t_sum += pairs[k][2]

        t_sum=t_sum/len(pairs)

        print("Temporal redundancy:", t_sum*100)
        print("Spatial Redundancy:", (sp_sum / (int(datasize / setsize)))*100)
        count=0

        #self.a_totalavge/=int(datasize / setsize)

        self.a_totalavge=self.a_totalavge/int(datasize / setsize)
        print("Accuracy:", (abs(self.b_totalavge - self.a_totalavge)/self.b_totalavge)*100)"""



    def formSet(self, tuple_list):
        temp=[]
        for i in range(len(tuple_list)):
            temp.append(tuple_list[i][0])
        #print("Temp:", temp)
        return temp


    def refineData(self, data):
        temp=[]
        llen=len(temp)
        for e in data:
            if e not in temp:
                temp.append(e)
        return temp


    def findRedundancyPercentage(self):
        temp=[]
        total=0

        #for i in range(int(self.wsn[0].dataSize/self.wsn[0].setsSize)):
        for s in self.wsn:
            temp.append(s.data)

        simi = list(all_pairs(temp, similarity_func_name="jaccard", similarity_threshold=0.1))
        sum = 0
        for k in simi:
            sum += k[2]
        total = sum / len(simi)
        print("Redundancy Before Aggregation", total * 100)

        return



s=CHaggregator(500,10,0.5,500,0.1, None)
#s.findRedundancyPercentage()
s.findSimilarity(500,10,None)


