from DataUpload import uploadData
import LinkedListStruct
import numpy as np
from Node import  Node
from RedundancyDetection import RedundancyDetector
from SetSimilaritySearch import all_pairs
from Tree import Tree
from TreeNode import treeNode
import math
import time
class RedundancyRemover:

    def __init__(self,readingSize, fno):
        self.nodeTree=Tree()
        self.RdDet=RedundancyDetector(fno)
        self.readSize=readingSize



    def buildTree(self, linkedlist):

         trNode = None
         if not self.RdDet.isRedundancyExist():
             return

         intersectedWithList=[]
         siblings=[]
         processedList=[]

         self.nodeTree.root = RedundancyRemover.formTreeNode(self, self.RdDet.lls.findNode(5))
         self.nodeTree.root.parent = None
         temp = self.nodeTree.root
         temp.children = self.RdDet.lls.findNode(5).getNeighbors()

         while True:
             temp.intersetedWith =RedundancyRemover.findNodesIntersectWith(self, temp, linkedlist)
             print("node id:", temp.node_id)
             intersectedWithList = intersectedWithList + temp.intersetedWith
             print("intersection with", temp.intersetedWith)
             if not RedundancyRemover.isInSiblings(self, temp.getNodeId(), siblings):
                 siblings.append(temp)
             print("neighbors:", temp.getChildren())
             for e in temp.getChildren():
                 if e not in processedList:
                     processedList.append(e)# = processedList + temp.getChildren()
             print("processdlist",processedList)
             for intersetedElement in intersectedWithList:
                 if intersetedElement in processedList:
                     intersectedWithList.remove(intersetedElement)
                     continue
                 trNode = RedundancyRemover.formTreeNode(self, self.RdDet.lls.findNode(intersetedElement))
                 siblings.append(trNode)
                 for e in trNode.getChildren():
                     if e not in processedList:
                         processedList.append(e)
                 #processedList=processedList+ trNode.getChildren()
                 if trNode.getNodeId() != temp.getNodeId():
                     temp.addSubnode(trNode)

                 for sb in siblings:
                     if sb.getNodeId() == trNode.getNodeId():
                         continue
                     intersection = RedundancyRemover.findCommonNieghors(self, trNode.getChildren(), sb.getChildren())
                     for int in intersection:
                         if RedundancyRemover.findNearestParent(self, self.RdDet.lls.findNode(int), trNode,
                                                                sb).getNodeId() == trNode.getNodeId():
                             if int in sb.children:
                                 sb.children.remove(int)
                         else:
                             trNode.children.remove(int)
                 processedList.append(intersetedElement)
             pnode=siblings.pop(0)
             processedList.append(pnode.getNodeId())
             #print("intersection:", intersectedWithList)
             ss=[e.getNodeId() for e in siblings]
             print("siblings:", ss)
             #print("Processed List", processedList)
             intersectedWithList=[]

             if len(siblings)==0:
                break
             else:
                 temp = siblings[0]





    def isInSiblings(self, element, siblings):

        for el in siblings:
            if int(el.getNodeId())==int(element):
                return True
        return False

    def isFoundInList(self,node, list):
        for element in list:
            if int(node.getNodeId()) == int(element.getNodeId()):
                return True
        return False


    def findParents(self,node, linkedlist):

        temp = linkedlist.head
        tempParents = []
        while temp is not None:
            #print(node)
            if node.getNodeId() in temp.getNeighbors():
                tempParents.append(temp)
            temp=temp.next
        return tempParents

    def refineTree(self):
        root = self.nodeTree.root
        queue = []
        prunelist=[]
        queue.append(root)

        while len(queue) > 0:
            temp = queue.pop(0)
            prunelist.append(temp.getNodeId())
            for node in temp.getChildren():
                if node in prunelist:
                    temp.deleteChild(node)
                else:
                    prunelist.append(node)
            queue = queue + temp.getSubnodes()
        return

    def fuseData(self, count):
        root = self.nodeTree.root
        queue = []

        coMatrices=[]
        fusedData=[]
        sum=0
        totalCovariance=0
        counter=1
        n=0
        queue.append(root)
        while len(queue) > 0:
            temp = queue.pop(0)
            coMatrices.append( np.linalg.inv(np.array([[0.9]])))
            reading=temp.getSensorReading()[count]
            n+=1
            sum+=np.dot(coMatrices[0], reading)
            totalCovariance+=coMatrices[0]
            for child in temp.getChildren():
                trNode=RedundancyRemover.formTreeNode(self, self.RdDet.lls.findNode(child))
                coMatrices.append(np.linalg.inv(np.array([[1.5]])))
                sum+=np.dot(coMatrices[counter], trNode.getSensorReading()[count])
                totalCovariance += coMatrices[counter]
                counter+=1
                n+=1
            z=np.dot(np.linalg.inv(totalCovariance),sum)

            fusedData.append(z)
            counter=1
            sum=0
            totalCovariance=0
            #print(coMatrices)
            coMatrices=[]
            queue = queue + temp.getSubnodes()
        #print("Fusion:", fusedData)
        #print("number of sensors:", n)
        return fusedData

    def getMEA(self, datasize):
        root = self.nodeTree.root
        queue = []
        tsum = 0

        queue.append(root)
        while len(queue) > 0:
            temp = queue.pop(0)
            tsum+=sum(temp.getSensorReading())/datasize
            for child in temp.getChildren():
                trNode = RedundancyRemover.formTreeNode(self, self.RdDet.lls.findNode(child))
                tsum += sum(trNode.getSensorReading())/len(trNode.getSensorReading())
            queue = queue + temp.getSubnodes()
        return tsum




    def findCommonNieghors(self, list_1, list_2):

        list_3 = [value for value in list_1 if value in list_2]
        return list_3


    def findNodesIntersectWith(self, node, linkedList):

        temp=linkedList.head
        intersectionList=[]
        while temp is not None:
            if int(temp.getNodeId()) != int(node.getNodeId()):
                if self.RdDet.IsIntersectWith(node,temp):
                    intersectionList.append(temp.getNodeId())
            temp=temp.next

        return intersectionList

    def findNearestParent(self, node, parent_1, parent_2):

        #print(type(parent_1),"    ", type(parent_2), "   ", type(node))

        if parent_1 is None:
            return parent_2

        if parent_2 is None:
            return parent_1

        dist_1 = self.RdDet.findDistance(parent_1.getCoord(), node.getCoord())
        dist_2 = self.RdDet.findDistance(parent_2.getCoord(), node.getCoord())

        if dist_1<dist_2:
            return parent_1

        return parent_2

    def findRoot(self, linkedlist):

        root=linkedlist.head
        #print(root.getNodeId())
        temp=linkedlist.head.next
        childrenList_1=0
        childrenList_2 = 0
        for element in root.getNeighbors():
            node=Node()
            node.setNodeId(element)
            node.setCoord(self.RdDet.lls.findNode(element).getCoord())
            p=RedundancyRemover.findNearestParent(self,node, linkedlist)
            if p is not None and p.getNodeId()==root.getNodeId():
                childrenList_1=childrenList_1+1


        # chech the other elements in the list
        while temp is not None:
            childrenList_2 = 0
            for element in temp.getNeighbors():
                node = Node()
                node.setNodeId(element)
                node.setCoord(self.RdDet.lls.findNode(element).getCoord())
                p = RedundancyRemover.findNearestParent(self, node, linkedlist)
                if p is not None and p.getNodeId() == temp.getNodeId():
                    childrenList_2 = childrenList_2 + 1

            if childrenList_2>childrenList_1:
                childrenList_1=childrenList_2

                root=temp
            temp=temp.next
        return root

    def formTreeNode(self, node):

        trNode=treeNode()
        node_id=node.getNodeId()
        trNode.setNodeId(node_id)
        trNode.setCoord(node.getCoord())
        trNode.setRadius(node.getRadius())
        trNode.children=node.getNeighbors()
        trNode.data=node.getSensorReading()

        return trNode

    def printList(self):
        root=self.nodeTree.root
        queue=[]
        queue.append(root)
        while len(queue)>0:
            temp=queue.pop(0)
            queue=queue+ temp.getSubnodes()
            print("node id:", temp.getNodeId())
            print("Neighbors:", temp.getChildren())


    def test(self, linkedList):
        temp=linkedList.head
        while temp is not None:
            tlist=RedundancyRemover.findNodesIntersectWith(self,temp, linkedList )
            if len(tlist)>0:
                print(temp.getNodeId(),"\n")
                for e in tlist:
                    print("node Id:", e.getNodeId())
            temp=temp.next

def round_up(n, decimals=0):
    multiplier = 10 ** decimals
    return math.ceil(n * multiplier) / multiplier

def test(readings, wsnsize):
    t = Tree()
    rr = RedundancyRemover(readings,wsnsize)
    # rr.RdDet.lls.printLinkedList()
    rr.buildTree(rr.RdDet.lls)
    rr.refineTree()
    rr.refineTree()




    b_simi = []
    elist = []
    temp = []
    est_avg=0.0
    sp_red = []
    t_red = []
    pairs = []
    spsum = 0
    count=0
    tlist=[]
    ftemp=[]
    for i in range(0, readings):
        ftemp = rr.fuseData(i)
        #print(ftemp)
        count+=abs(wsnsize-len(ftemp))/wsnsize
        print((len(ftemp)/wsnsize))
        tlist.append(i for i in ftemp )
    print(tlist)

    #rr.RdDet.lls.printLinkedList()
    #print("####################################################################")
    #rr.printList()





    """for i in range(0, readings):
        ftemp = rr.fuseData(i)
        #print("fused data:", ftemp)
        for e in ftemp:
            temp.append(e[0][0])
            sp_red.append([e[0][0]])
            elist.append(e[0][0])
        est_avg += sum(elist)/len(ftemp)

        elist=[]
        pairs = list(all_pairs(sp_red, similarity_func_name="jaccard", similarity_threshold=0.0))
        for e in pairs:
            spsum += e[2]
        spsum = spsum / len(sp_red)
        t_red.append(temp)
        sp_red = []
        b_simi.append(temp)
        temp = []

    pairs = list(all_pairs(t_red, similarity_func_name="jaccard", similarity_threshold=0.0))
    tsum = 0
    for e in pairs:
        tsum += e[2]
    print("Temporal Redundancy:", tsum / len(pairs) * 100, "%")
    print("Spatial Redundancy:", round_up(spsum / len(t_red), 4) * 100, "%")

    est_avg = est_avg/readings

    act_avg = rr.getMEA(readings)/wsnsize
    print(est_avg, "    ", act_avg)
    print("Accuracy:",( (abs(act_avg - est_avg) / act_avg))*100,"%")
    #pairs = list(all_pairs(b_simi, similarity_func_name="jaccard", similarity_threshold=0.0))
    #rr.printList()"""


test(100,50)


