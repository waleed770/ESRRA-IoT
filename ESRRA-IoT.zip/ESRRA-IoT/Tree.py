
class Tree:
    def __init__(self):
        self.root=None

    def insertNode(self, parent, child):

        if parent!=None:
            parent.addChild(child)
    def deleteChild(self, nodeId):
        root=self.root
        if root.getNodeID()==nodeId:
            return self.root

    def findNode(self,currentNode, nodeId):

        if currentNode.getNodeID()==nodeId:
            return currentNode
        if len(currentNode.getChildren())==0:
            return
        for child in currentNode.getChildren():
             Tree.findNode(self, child, nodeId)

