from SetSimilaritySearch import all_pairs


def getSpoTemporalRedundancy(sensors, datasize):
    datasetArray={}
    sp_red=[]
    t_red=[]
    sp_sum=0.0
    sp_temp=[]
    t_sum=0.0
    pairs=[]
    for i in range (1, sensors+1):
        datasetArray[i]=getData(i,datasize)
        sp_red.append(refineData(datasetArray[i]))

    for j in range(0, datasize):

        for k in range(1,len(datasetArray)):

            sp_temp.append(datasetArray[k][j])
        #print(sp_red)
        t_red.append(sp_temp)
        sp_temp=[]
    pairs = list(all_pairs(sp_red, similarity_func_name="jaccard", similarity_threshold=0.0))
    temp = 0
    for e in pairs:
        temp += e[2]
    if len(pairs) > 0:
        sp_sum += (temp / len(pairs))  # temp/len(pairs)
    sp_red = []


    stemp=0

    pairs = list(all_pairs(t_red, similarity_func_name="jaccard", similarity_threshold=0.1))
    for e in pairs:
        stemp += e[2]
    if len(pairs) > 0:
        t_sum = stemp / len(pairs)

    print("spatial Redundancy:", (sp_sum) *100)
    print("Temporal Redundancy:", (t_sum ) * 100)


def refineData(data):
    temp = []
    llen = len(temp)
    for e in data:
        if e not in temp:
            temp.append(e)
    return temp


def getData(sensor_id, dataSize):
    readingList = []
    count = 0

    try:
        f = open("datasets/Sensor_" + str(sensor_id) + ".txt", 'r')
        while True:
            readline = f.readline()
            if readline == '':
                break
            count += 1
            if count > dataSize:
                break

            if " " not in readline:
                readingList.append(float(readline))
    except IOError as e:
        print(" file cann't be found or open")
    # readingList=refineData(readingList)
    return readingList

getSpoTemporalRedundancy(450, 500)
